**********************************************************
:mod:`cherrypy.process.win32` -- Bus support for Windows
**********************************************************

.. automodule:: cherrypy.process.win32

Classes
=======

.. autoclass:: ConsoleCtrlHandler
   :members:

.. autoclass:: Win32Bus
   :members:

.. autoclass:: PyWebService
   :members:
